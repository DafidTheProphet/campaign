---
title: Way of the Earthen Soul
draft: false
tags:
---
When you take this monastic tradition at third level, you gain access to the cantrips mold earth, and elemental attunement. 

### Earth Manipulation

You gain the ability to use your internal energy to manipulate the surrounding earth. You gain the ability to cast spells listed in the table below at the cost of qi points. You may upcast the spells for 1 qi point per additional level to a maximum defined in the table. The spell save DC for these abilities is your cultivation save DC or 8 + proficiency + wis, at the player’s choice. 

|       |             |                                         |              |
| ----- | ----------- | --------------------------------------- | ------------ |
| Level | Max Qi Cost | Spell                                   | Base Qi Cost |
| 3     | 2           | Earth Tremor                            | 1            |
| 6     | 3           | Maximillian’s Earthen Grasp             | 2            |
| 11    | 4           | Erupting Earth, Melf’s Minute Meteors\* | 3            |
| 14    | 5           | Stoneskin\*, Stone Shape                | 4            |
| 17    | 6           | Wall of Stone\*, Transmute Stone        | 5            |
\* Altered Spells 

#### Modified Abilities
A few spells have been modified to be more appropriate for this monastic tradition. These modified spells can only be cast by this monastic tradition using qi points.  None of these spells require the caster to possess material components, however, earthen terrain (stone, dirt, etc.) must be present within 60ft of the caster. 
- Melf's Minute Meteors: Deals bludgeoning damage instead of fire damage. 
- Stoneskin: The caster must be on earthen terrain and can only cast the spell upon themselves. The duration is 1 minute (10 rounds). 
- Wall of Stone: Casting the spell does not require concentration. The duration of this spell is 1 minute (10 rounds). 